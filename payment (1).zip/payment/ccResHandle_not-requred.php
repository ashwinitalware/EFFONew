<?php include('Crypto.php')?>


<?php
    $ch = curl_init();
	error_reporting(0);
	
	$workingKey='D7445CFC4A0132DB6BF00A9ECBDB5A95';		//Working Key should be provided here.
	$encResponse=$_POST["encResp"];			//This is the response sent by the CCAvenue Server
	$rcvdString=decrypt($encResponse,$workingKey);		//Crypto Decryption used as per the specified working key.
	$order_status="";
	$decryptValues=explode('&', $rcvdString);
	$dataSize=sizeof($decryptValues);


    $url = "https://webhook.site/236980a1-016c-414c-9b70-8f3470553444";
    $data = json_encode($decryptValues);

    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
    $response = curl_exec($ch);
    if(curl_errno($ch)) {
        // Handle error
        echo 'cURL Error: ' . curl_error($ch);
    }
    
    curl_close($ch);
    
    
	echo "<center>";

	for($i = 0; $i < $dataSize; $i++) 
	{
		$information=explode('=',$decryptValues[$i]);
		if($i==3)	$order_status=$information[1];
	}

	if($order_status==="Success")
	{
		echo "<br>Thank you for shopping with us. Your credit card has been charged and your transaction is successful. We will be shipping your order to you soon.";
		    header("Location: https://api.effoapp.com/api/custom/payment/success");
    exit();
		
	}
	else if($order_status==="Aborted")
	{
				header("Location: https://api.effoapp.com/api/custom/payment/fail");
    exit();
		echo "<br>Thank you for shopping with us.We will keep you posted regarding the status of your order through e-mail";
	
	}
	else if($order_status==="Failure")
	{
		header("Location: https://api.effoapp.com/api/custom/payment/fail");
    exit();
		echo "<br>Thank you for shopping with us.However,the transaction has been declined.";
	}
	else
	{
				header("Location: https://api.effoapp.com/api/custom/payment/fail");
    exit();
		echo "<br>Security Error. Illegal access detected";
	
	}

	echo "<br><br>";

	echo "<table cellspacing=4 cellpadding=4>";
	for($i = 0; $i < $dataSize; $i++) 
	{
		$information=explode('=',$decryptValues[$i]);
	    	echo '<tr><td>'.$information[0].'</td><td>'.$information[1].'</td></tr>';
	}

	echo "</table><br>";
	echo "</center>";
?>
