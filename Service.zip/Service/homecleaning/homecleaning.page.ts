import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homecleaning',
  templateUrl: './homecleaning.page.html',
  styleUrls: ['./homecleaning.page.scss'],
})
export class HomecleaningPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
