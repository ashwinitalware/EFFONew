import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-subservices',
  templateUrl: './subservices.page.html',
  styleUrls: ['./subservices.page.scss'],
})
export class SubservicesPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
