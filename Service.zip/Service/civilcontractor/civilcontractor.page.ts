import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-civilcontractor',
  templateUrl: './civilcontractor.page.html',
  styleUrls: ['./civilcontractor.page.scss'],
})
export class CivilcontractorPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
