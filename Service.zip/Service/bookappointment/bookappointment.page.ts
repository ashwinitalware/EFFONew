import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bookappointment',
  templateUrl: './bookappointment.page.html',
  styleUrls: ['./bookappointment.page.scss'],
})
export class BookappointmentPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
