import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-electronicsservices',
  templateUrl: './electronicsservices.page.html',
  styleUrls: ['./electronicsservices.page.scss'],
})
export class ElectronicsservicesPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
