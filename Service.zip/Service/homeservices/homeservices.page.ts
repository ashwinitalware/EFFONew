import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homeservices',
  templateUrl: './homeservices.page.html',
  styleUrls: ['./homeservices.page.scss'],
})
export class HomeservicesPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
