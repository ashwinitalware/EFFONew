import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-automobileservice',
  templateUrl: './automobileservice.page.html',
  styleUrls: ['./automobileservice.page.scss'],
})
export class AutomobileservicePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
