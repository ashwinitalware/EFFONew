import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pestcontrolservice',
  templateUrl: './pestcontrolservice.page.html',
  styleUrls: ['./pestcontrolservice.page.scss'],
})
export class PestcontrolservicePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
