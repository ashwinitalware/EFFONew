import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-allservices',
  templateUrl: './allservices.page.html',
  styleUrls: ['./allservices.page.scss'],
})
export class AllservicesPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
