import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-acservice',
  templateUrl: './acservice.page.html',
  styleUrls: ['./acservice.page.scss'],
})
export class AcservicePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
